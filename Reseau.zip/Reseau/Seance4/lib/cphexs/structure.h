struct Data
      {
       int Valeur ;
       char message[40] ; 
      } ;

#ifndef CLIENT_H
#define CLIENT_H
#include "Informations.h"
#endif
struct Message
{
  int Entier1 ;
  int Entier2 ;
  int Resultat ;
  char Commentaire[200] ;
};
  

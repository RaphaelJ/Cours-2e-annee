struct Record { 
         int Numero ;
	 int Valeur ;
	 char Memo[80] ;
	} ;
